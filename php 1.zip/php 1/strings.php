<!-- Título principal desta página. -->
<h1>Strings</h1>

<?php
// Cria duas variáveis de texto (strings).
$string1 = 'Casa';
$string2 = 'Mundo';

// strlen() conta o comprimento de cada string.
echo '<p>Primeira string: ' . $string1 . '</p>';
echo '<p>Comprimento da primeira string: ' . strlen($string1) . '</p>';
echo '<p>Segunda string: ' . $string2 . '</p>';
echo '<p>Comprimento da segunda string: ' . strlen($string2) . '</p>';

// Compara os textos; === verifica se têm o mesmo valor e tipo.
if ($string1 === $string2) {
    // Este texto aparece quando as strings são iguais.
    echo '<p>As strings são iguais.</p>';
} else {
    // Este texto aparece quando as strings são diferentes.
    echo '<p>As strings são diferentes.</p>';
}
?>
