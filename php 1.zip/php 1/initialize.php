<?php
// Define uma constante com os nomes das páginas, pela ordem do menu.
// Os índices começam em 0: home é 0, vars é 1, e assim sucessivamente.
define('PAGES', ['home', 'vars', 'strings', 'arrays', 'about']);

// Lê o valor de "p" enviado pelo URL, por exemplo: ./?p=1.
// Se "p" não existir, usa 0, que corresponde à página home.
$current_page = isset($_GET['p']) ? (int) $_GET['p'] : 0;

// Esta função cria e devolve o HTML do menu.
function generate_menu()
{
    // Abre a lista HTML do menu.
    $html = '<ul>';

    // Percorre PAGES: $index recebe o índice e $page recebe o nome.
    foreach (PAGES as $index => $page) {
        // Junta ao menu uma ligação para a página correspondente.
        $html .= '<li><a href="./?p=' . $index . '">' . $page . '</a></li>';
    }

    // Fecha a lista e devolve todo o HTML criado.
    $html .= '</ul>';
    return $html;
}

// Esta função devolve o nome da página correspondente ao índice atual.
function get_current_page_name()
{
    // Confirma que existe uma página com o índice recebido.
    if (isset(PAGES[$GLOBALS['current_page']])) {
            // Devolve o nome dessa página, por exemplo "vars".
        return PAGES[$GLOBALS['current_page']];
    }

    // Se o índice não existir, devolve a primeira página: home.
    return PAGES[0];
}
