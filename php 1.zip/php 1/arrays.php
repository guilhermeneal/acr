<!-- Título principal desta página. -->
<h1>Arrays</h1>

<?php
// Array indexado: os elementos recebem índices numéricos automáticos (0, 1, 2).
$indexed_array = ['maçã', 'banana', 'laranja'];

// Array associativo: cada valor é identificado por uma chave com nome.
$associative_array = [
    'nome' => 'Ana',
    'idade' => 20,
    'cidade' => 'Lisboa'
];

// print_r mostra o array; o segundo argumento true devolve o resultado como texto.
// Assim, esse texto fica guardado numa variável em vez de ser mostrado logo.
$indexed_array_output = print_r($indexed_array, true);
$associative_array_output = print_r($associative_array, true);

// <pre> mantém a formatação; htmlspecialchars torna o texto seguro para HTML.
// echo imprime na página o conteúdo guardado nas variáveis.
echo '<pre>' . htmlspecialchars($indexed_array_output) . '</pre>';
echo '<pre>' . htmlspecialchars($associative_array_output) . '</pre>';
?>
