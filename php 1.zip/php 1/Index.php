<?php
// Inclui as páginas, a variável da página atual e as funções partilhadas.
include 'initialize.php';
?>
<!-- Declara que este documento usa HTML5. -->
<!DOCTYPE html>
<!-- Elemento principal do documento; lang indica que o idioma é português. -->
<html lang="pt">
<head>
    <!-- Permite apresentar corretamente caracteres como á e ç. -->
    <meta charset="UTF-8">
    <!-- Texto apresentado no separador do navegador. -->
    <title>Aplicações Centradas em Redes</title>
</head>
<body>
    <?php
    // Chama a função e usa echo para mostrar o menu na página.
    echo generate_menu();

    // Descobre o nome atual, por exemplo "home" ou "vars".
    $page_name = get_current_page_name();
    // Junta o nome com ".php" e inclui o ficheiro, por exemplo home.php.
    include $page_name . '.php';
    ?>
</body>
</html>
