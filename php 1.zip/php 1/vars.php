<!-- Título principal desta página. -->
<h1>Vars</h1>

<?php
// Cria duas variáveis numéricas de exemplo.
$number1 = 10;
$number2 = 5;
// Soma os valores e guarda o resultado noutra variável.
$sum = $number1 + $number2;

// echo mostra o texto e os valores no HTML da página.
echo '<p>Primeiro valor: ' . $number1 . '</p>';
echo '<p>Segundo valor: ' . $number2 . '</p>';
echo '<p>Soma: ' . $sum . '</p>';
?>
