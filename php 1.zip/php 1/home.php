<!-- Título principal da página inicial. -->
<h1>Home</h1>
<!-- Subtítulo pedido no enunciado do exercício. -->
<h2>Exercício 2 – home page</h2>
