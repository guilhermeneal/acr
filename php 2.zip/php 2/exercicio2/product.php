<?php
require_once __DIR__ . '/classes/product.php';
session_start();
Product::initClass();
$_SESSION['produtos'] ??= [];

$produto = null;
if (isset($_GET['id'])) {
    foreach ($_SESSION['produtos'] as $item) {
        if ($item->id == $_GET['id']) {
            $produto = $item;
            break;
        }
    }
}

function escapar($valor)
{
    return htmlspecialchars((string) $valor, ENT_QUOTES, 'UTF-8');
}
?>
<!doctype html>
<html lang="pt">
<head>
    <meta charset="utf-8">
    <title><?= $produto ? 'Editar Produto' : 'Novo Produto' ?></title>
</head>
<body>
    <h1>Exercício 3</h1>
    <h2><?= $produto ? 'Editar Produto' : 'Novo Produto' ?></h2>

    <form action="saveproduct.php" method="post">
        <input type="hidden" name="id" value="<?= $produto ? (int) $produto->id : '' ?>">
        <p><label>Nome: <input type="text" name="name" value="<?= escapar($produto->name ?? '') ?>" required></label></p>
        <p><label>Descrição: <input type="text" name="description" value="<?= escapar($produto->description ?? '') ?>" required></label></p>
        <p><label>Valor: <input type="number" name="value" min="0" step="0.01" value="<?= escapar($produto->value ?? '') ?>" required></label></p>
        <button type="submit">Guardar</button>
    </form>

    <p><a href="index.php">Voltar à lista</a></p>
</body>
</html>
