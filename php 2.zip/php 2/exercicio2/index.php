<?php
require_once __DIR__ . '/classes/product.php';
session_start();
Product::initClass();
$_SESSION['produtos'] ??= [];
?>
<!doctype html>
<html lang="pt">
<head>
    <meta charset="utf-8">
    <title>Exercício 3</title>
</head>
<body>
    <h1>Exercício 3</h1>
    <p><a href="product.php">Criar novo produto</a></p>

    <ul>
        <?php foreach ($_SESSION['produtos'] as $produto): ?>
            <?= $produto->listItem() ?>
        <?php endforeach; ?>
    </ul>

    <p><a href="clear.php">Limpar sessão</a></p>
</body>
</html>
